
function verifikasi() {
  const input = document.getElementById("kode").value.trim();
  const hasil = document.getElementById("hasil");
  if (input === "LUMIERO2025") {
    hasil.innerHTML = "<span style='color: silver;'>✅ Kode valid. Produk ASLI.</span>";
  } else {
    hasil.innerHTML = "<span style='color: red;'>❌ Kode tidak valid atau palsu.</span>";
  }
}
